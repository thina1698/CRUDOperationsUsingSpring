package com.hibernate.student.dao;
import org.hibernate.SessionFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import com.hibernate.student.model.Student;

@SpringBootTest
public class StudentDAOImpTest {
	
	@InjectMocks
	private StudentDAOImp studentDAOImp;
	
	@Mock
	private SessionFactory sessionFactory;
	
	@BeforeEach
	private void setUp() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	public Student getStudentTest(){
		Student stu=new Student(1, "Thina", "KMU");
		return stu;
	}

	
	
}
