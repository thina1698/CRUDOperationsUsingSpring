package com.hibernate.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hibernate.student.model.Student;
import com.hibernate.student.service.StudentService;

@RestController
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	@GetMapping("/getStudents")
	public List<Student> getStudents(){
		return studentService.getStudents();
	}
	
	@PostMapping("/addStudents")
	public Student addStudents(@RequestBody Student student){
		return studentService.addStudents(student);
	}
	
	@PutMapping("/updateStudents")
	public Student updateStudents(@RequestBody Student student){
		return studentService.updateStudents(student);
	}
	
	@DeleteMapping("/deleteStudents/{studentId}")
	public String deleteStudents(@PathVariable int studentId){
		return studentService.deleteStudents(studentId);
	}








}
