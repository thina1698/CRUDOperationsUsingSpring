package com.hibernate.student.dao;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.hibernate.student.model.Student;
import com.hibernate.student.util.StudentUtil;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.transaction.Transactional;

@Repository
public class StudentDAOImp implements StudentDAO {
	
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	@Transactional
	public List<Student> getStudents() {
		
		 Session session=StudentUtil.getSession(sessionFactory);
		 Query query = session.createNativeQuery("select STUDENT_ID,STUDENT_NAME,STUDENT_ADD from stutable",Student.class);
		 return query.getResultList();
	}

	@Override
	@Transactional
	public Student addStudents(Student student) {
		 Session session=StudentUtil.getSession(sessionFactory);
		 session.beginTransaction();
		 session.persist(student);
		 session.getTransaction().commit();
		 return student;
	}

	@Override
	@Transactional
	public Student updateStudents(Student student) {
		 Session session=StudentUtil.getSession(sessionFactory);
		 session.beginTransaction();
		 session.merge(student);
		 session.getTransaction().commit();
		 return student;
		
	}

	@Override
	@Transactional
	public String deleteStudents(int studentId) {
		 Session session=StudentUtil.getSession(sessionFactory);
		 session.beginTransaction();
		 Student load = session.getReference(Student.class, studentId);
		 session.remove(session.contains(load)? load :session.merge(load));
		 session.getTransaction().commit();
		 return "Student Deleted";
	}

}
