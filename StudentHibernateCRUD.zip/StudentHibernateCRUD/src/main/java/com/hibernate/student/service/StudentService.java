package com.hibernate.student.service;

import java.util.List;

import com.hibernate.student.model.Student;

public interface StudentService {

	List<Student> getStudents();

	Student addStudents(Student student);

	Student updateStudents(Student student);

	String deleteStudents(int studentId);










}
