package com.hibernate.student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentHibernateCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentHibernateCrudApplication.class, args);
	}

}
