package com.hibernate.student.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hibernate.student.dao.StudentDAO;
import com.hibernate.student.model.Student;

@Service
public class StudentServiceImp implements StudentService {
	
	@Autowired
	private StudentDAO studentDAO;

	@Override
	public List<Student> getStudents() {
		return studentDAO.getStudents();
	}

	@Override
	public Student addStudents(Student student) {
		return studentDAO.addStudents(student);
	}

	@Override
	public Student updateStudents(Student student) {
		return studentDAO.updateStudents(student);
	}

	@Override
	public String deleteStudents(int studentId) {
		return studentDAO.deleteStudents(studentId);
	}

}
