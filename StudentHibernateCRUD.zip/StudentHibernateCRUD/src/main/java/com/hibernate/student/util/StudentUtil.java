package com.hibernate.student.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class StudentUtil {
		
	public static  Session getSession(SessionFactory sessionFactory) {
				 	return sessionFactory.openSession();
				 	
  }
}
