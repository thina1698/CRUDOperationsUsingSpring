package com.hibernate.student.dao;

import java.util.List;

import com.hibernate.student.model.Student;

public interface StudentDAO {

	List<Student> getStudents();

	Student addStudents(Student student);

	Student updateStudents(Student student);

	String deleteStudents(int studentId);

}
